# Shakha 360 Login Filler

A small Chrome / Edge extension. In Shakha → Compliance → Client Logins, **Open and sign in** opens the portal in a new tab and fills the client's user ID and password. You type the captcha or OTP and click Login yourself.

Portals: Income Tax, GST, TRACES, MCA, EPFO, ESIC, E-way bill.

## Install

1. In Shakha → Compliance → Client Logins, click **Download the Login Filler**.
2. In your Downloads, right-click **shakha-login-filler.zip** and choose **Extract All**. Keep the folder somewhere it won't be deleted, such as Documents.
3. Open a new tab and go to `chrome://extensions` (in Edge: `edge://extensions`).
4. Turn on **Developer mode** (top right in Chrome, left side in Edge).
5. Click **Load unpacked** and choose the extracted **shakha-login-filler** folder.
6. Reload Shakha. The download box on Client Logins disappears once the filler is working.

**To update:** download it again, extract it over the same folder, and click the reload arrow on the Login Filler in `chrome://extensions`. Shakha shows the download box again whenever a newer version is out.

## On each portal

| Portal | What happens |
|---|---|
| GST, EPFO, E-way bill | Both boxes are filled at once. |
| Income Tax | The user ID is filled. Click **Continue**, and the password fills on the next screen. |
| TRACES | The page is drawn as a picture, and its boxes only exist while you type in them. Click the **User ID** box, then the **Password** box; each fills as you click it. The Deductor tab is selected already. For a taxpayer login, pick Taxpayer first. |
| MCA | The first time, MCA may ask for a language and show its home page. Choose the language and click **Login/Register**. The boxes fill there, even when the login opens in a new tab. |
| ESIC | The visible password box and the text box just before it are filled. |

## What it never does

- It never types the captcha or OTP.
- It never ticks a box.
- It never clicks Login.

## Keeping the password safe

- Shakha fetches the password only when you click. This is recorded under **Who viewed passwords**, the same as Show.
- The extension holds the password in memory for up to 4 minutes, and only for:
  - the tab it opened, or a tab that tab opens;
  - that portal's own web addresses.
- It is deleted as soon as the boxes are filled, or when the tab closes. It is never saved to disk, and no other website can get it.

## Limits

- It works only in Chrome or Edge on a computer. It does not work in the Android app.
- If a portal changes its login page, the filler shows a note saying it could not fill the page. Use Copy in Shakha until the filler is updated.
