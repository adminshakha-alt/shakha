/* Shakha 360 Login Filler: the background part.
   Shakha hands over one login (portal, user ID, password) when someone clicks Open and sign in. It is kept for 2 minutes in
   Chrome's session storage (held in memory, never written to disk, gone when the browser closes, and not readable by web
   pages or by the extension's page scripts), tied to the tab this opens and to that portal's own web addresses. The portal
   page in that tab asks for it, fills the boxes, and it is deleted. No other site or tab can get it. */
const PORTALS = {
  'Income Tax': ['eportal.incometax.gov.in'],
  'GST': ['services.gst.gov.in'],
  'TRACES': ['www.tdscpc.gov.in', 'traces.tdscpc.gov.in'],
  'MCA': ['www.mca.gov.in', 'mca.gov.in'],
  'EPFO': ['unifiedportal-emp.epfindia.gov.in'],
  'ESIC': ['portal.esic.gov.in', 'gateway.esic.gov.in'],
  'E-way bill': ['ewaybillgst.gov.in']
};
const LIFE = 240000; /* 4 minutes: MCA may first ask for a language and send you to its home page */
const key = id => 'fill_' + id;
const hostOf = u => { try { return new URL(u).hostname; } catch (e) { return ''; } };
const S = chrome.storage.session;
try { S.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }); } catch (e) { }

async function take(tabId) { const k = key(tabId); const o = (await S.get(k))[k]; if (!o) return null; if (o.exp < Date.now()) { await S.remove(k); return null; } return o; }

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  /* from Shakha's page (through shakha.js): open the portal and keep the login for that tab */
  if (m && m.type === 'open') {
    const hosts = PORTALS[m.portal]; const url = String(m.url || '');
    if (!hosts || hosts.indexOf(hostOf(url)) < 0 || !/^https:/.test(url)) { reply({ ok: false, error: 'This portal is not one the filler knows.' }); return; }
    if (!m.user) { reply({ ok: false, error: 'No user ID.' }); return; }
    chrome.tabs.create({ url, index: sender.tab ? sender.tab.index + 1 : undefined }, async tab => {
      await S.set({ [key(tab.id)]: { portal: m.portal, user: String(m.user), pw: String(m.pw || ''), exp: Date.now() + LIFE, group: tab.id } });
      reply({ ok: true });
    });
    return true;
  }
  /* from a portal page (fill.js): only the tab opened for it, only on that portal's own address */
  if (m && m.type === 'get') {
    const tabId = sender.tab && sender.tab.id;
    take(tabId).then(p => reply(p && (PORTALS[p.portal] || []).indexOf(hostOf(sender.url)) >= 0 ? { portal: p.portal, user: p.user, pw: p.pw, left: p.exp - Date.now() } : null));
    return true;
  }
  /* filled: forget it in this tab and in any tab it came from or led to */
  if (m && m.type === 'done') { const id = sender.tab && sender.tab.id;
    take(id).then(async p => { const ks = [key(id)]; if (p && p.group) { const all = await S.get(null); Object.keys(all).forEach(k => { if (/^fill_/.test(k) && all[k].group === p.group) ks.push(k); }); } await S.remove(ks); reply({ ok: true }); }); return true; }
  if (m && m.type === 'ping') { reply({ ok: true, version: chrome.runtime.getManifest().version }); return; }
});
chrome.tabs.onRemoved.addListener(id => { S.remove(key(id)); });
/* a portal that opens its login in a new tab (MCA's Login/Register): the new tab gets the same login, still only for that
   portal's own addresses (checked when the page asks), and only until the same time */
chrome.tabs.onCreated.addListener(async tab => { if (!tab.openerTabId) return; const p = await take(tab.openerTabId); if (p) await S.set({ [key(tab.id)]: p }); });
