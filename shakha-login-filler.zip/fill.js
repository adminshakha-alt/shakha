/* Shakha 360 Login Filler: the part that runs on the portals.
   Only in the tab Shakha opened (or a tab opened from it, as MCA does), and only for a few minutes, it fills the user ID and
   the password. It never types the captcha or OTP and never clicks Login: the person does that.
   - Income Tax shows the password box after Continue: the user ID is filled first, the password when its box appears.
   - TRACES is drawn on a canvas (Flutter): its boxes exist only while being typed in, so the person clicks the User ID box and
     then the Password box, and each is filled as it is clicked. */
(function () {
  if (window.top !== window) return;
  const H = location.hostname;
  /* the boxes of each portal; where a portal isn't listed, the visible password box and the text box just before it */
  const KNOWN = {
    'eportal.incometax.gov.in': { user: '#panAdhaarUserId', pw: '#loginPasswordField' },
    'services.gst.gov.in': { user: '#username', pw: '#user_pass' },
    'unifiedportal-emp.epfindia.gov.in': { user: '#username1', pw: '#password' },
    'ewaybillgst.gov.in': { user: '#txt_username', pw: '#txt_password' },
    'www.mca.gov.in': { user: 'input[name=userID]', pw: 'input[name=password]' },
    'mca.gov.in': { user: 'input[name=userID]', pw: 'input[name=password]' }
  };
  const K = KNOWN[H] || {};
  const seen = el => !!el && !el.disabled && el.offsetParent !== null && el.getClientRects().length > 0;
  /* "otp" only as a word of its own (OTPField, otp_box), not inside another word: MCA's user ID box is "…rootPanel…" */
  const notCaptcha = el => !/captcha|search|(^|[^a-z])otp/i.test([el.id, el.name, el.placeholder, el.getAttribute('aria-label')].join(' '));
  /* a page can have several boxes of the same name (MCA has hidden copies): take the first one that is on screen */
  const visible = sel => sel ? [...document.querySelectorAll(sel)].find(seen) || null : null;
  function pwBox() { return visible(K.pw) || [...document.querySelectorAll('input[type=password]')].find(seen) || null; }
  function userBox() {
    const k = visible(K.user); if (k) return k;
    const pw = pwBox(); if (!pw) return null;
    const L = [...document.querySelectorAll('input')].filter(i => seen(i) && /^(text|email|tel|)$/i.test(i.type) && notCaptcha(i));
    const before = L.filter(i => i.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING); return before[before.length - 1] || null;
  }
  /* sets the value the way a person typing would, so Angular, AEM forms and Flutter notice it */
  function put(el, v, keepFocus) {
    if (el.readOnly) el.readOnly = false;
    el.focus(); const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; set.call(el, v);
    try { el.setSelectionRange(v.length, v.length); } catch (e) { }
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: v }));
    ['change', 'keyup'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
    if (!keepFocus) { el.dispatchEvent(new FocusEvent('focusout', { bubbles: true })); el.dispatchEvent(new FocusEvent('blur')); }
  }
  function note(text, stay) {
    let n = document.getElementById('shakha-filler-note');
    if (!n) { n = document.createElement('div'); n.id = 'shakha-filler-note'; n.setAttribute('role', 'status');
      n.style.cssText = 'position:fixed;z-index:2147483647;right:16px;bottom:16px;max-width:340px;background:#17614A;color:#fff;font:14px/1.45 Arial,sans-serif;padding:10px 14px;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.25);cursor:pointer';
      n.onclick = () => n.remove(); document.documentElement.appendChild(n); }
    n.textContent = text; clearTimeout(n._t); if (!stay) n._t = setTimeout(() => n.remove(), 12000);
  }
  const isFlutter = () => !!document.querySelector('flutter-view, flt-glass-pane, flt-text-editing-host');
  const log = (...a) => console.info('[Shakha Login Filler]', ...a);
  chrome.runtime.sendMessage({ type: 'get' }, got => {
    if (chrome.runtime.lastError) { log('no answer from the extension', chrome.runtime.lastError.message); return; }
    if (!got) { log('nothing to fill in this tab'); return; }
    log('filling', got.portal, 'on', H);
    note('Shakha is filling the ' + got.portal + ' login…', true);
    let userDone = false, pwDone = !got.pw, flutter = false, typed = false; const until = Date.now() + Math.max(0, got.left); const t0 = Date.now();
    document.addEventListener('input', e => { if (e.isTrusted) typed = true; }, true);
    /* 1.2: some pages (MCA's form system) redraw or clear the form after it loads. For 15 seconds after filling, put the
       values back if they disappear, unless the person has started typing. */
    const finish = () => { stop(); note('Shakha filled the user ID and password. Type the captcha or OTP and log in.');
      if (flutter) { chrome.runtime.sendMessage({ type: 'done' }); return; }
      const end = Date.now() + 15000; let refills = 0;
      const guard = setInterval(() => {
        if (typed || Date.now() > end) { clearInterval(guard); chrome.runtime.sendMessage({ type: 'done' }); log('done', refills ? '(filled again ' + refills + ' times)' : ''); return; }
        const u = userBox(), p = pwBox();
        if (u && u.value !== got.user) { put(u, got.user); refills++; }
        if (p && got.pw && p.value !== got.pw) { put(p, got.pw); refills++; }
      }, 500); };
    const why = () => { const pws = [...document.querySelectorAll('input[type=password]')]; return 'user ID box ' + (userBox() ? 'found' : 'not found') + ', password boxes ' + pws.filter(seen).length + ' visible of ' + pws.length; };
    /* Flutter pages (TRACES): fill each box as the person clicks into it */
    const onFocus = e => {
      const el = e.target; if (!flutter || !el || el.tagName !== 'INPUT' || !el.closest('flt-text-editing-host')) return;
      setTimeout(() => {
        if (el.type === 'password' && !pwDone) { put(el, got.pw, true); pwDone = true; }
        else if (el.type !== 'password' && !userDone && !el.value) { put(el, got.user, true); userDone = true; if (!pwDone) note('Shakha filled the user ID. Now click the Password box.', true); }
        if (userDone && pwDone) finish();
      }, 60);
    };
    document.addEventListener('focusin', onFocus, true);
    const tick = () => {
      if (!flutter && isFlutter()) { flutter = true; if (!userDone) note('Click the User ID box, then the Password box: Shakha fills each one as you click it.', true); }
      if (Date.now() > until) { stop(); chrome.runtime.sendMessage({ type: 'done' }); if (!userDone) note('Shakha could not fill this page in time. Click Open and sign in in Shakha again, or use Copy.'); return; }
      if (!flutter && !userDone && Date.now() - t0 > 20000 && !tick.told) { tick.told = true; log('still looking:', why()); note('Shakha has the login but can\'t find the boxes on this page yet (' + why() + '). It keeps trying for a few minutes.', true); }
      if (flutter) return;
      if (!userDone) { const u = userBox(); if (u) { put(u, got.user); userDone = true; if (!pwBox() && got.pw) note('Shakha filled the user ID. Click Continue; the password is filled on the next screen.'); } }
      if (userDone && !pwDone) { const p = pwBox(); if (p) { put(p, got.pw); pwDone = true; } }
      if (userDone && pwDone) finish();
    };
    const iv = setInterval(tick, 400); const mo = new MutationObserver(tick); mo.observe(document.documentElement, { childList: true, subtree: true });
    function stop() { clearInterval(iv); mo.disconnect(); document.removeEventListener('focusin', onFocus, true); }
    tick();
  });
})();
