/* Shakha 360 Login Filler: the part that runs on Shakha's own pages.
   It tells Shakha the filler is installed, and passes an Open and sign in request (portal, address, user ID, password) from
   that page to the background part. It accepts messages only from the page itself, never from another site or frame.
   1.2.2: the website's /app page loads Shakha by replacing itself (document.open / write), which removes the mark on <html>
   and the message listener. Both are put back whenever that happens. */
(function () {
  if (window.top !== window) return;
  const ver = chrome.runtime.getManifest().version;
  function onMsg(e) {
    if (e.source !== window || e.origin !== location.origin) return;
    const m = e.data; if (!m || m.type !== 'SHAKHA_FILL' || !m.id) return;
    let done = false; const answer = r => { if (done) return; done = true; window.postMessage({ type: 'SHAKHA_FILL_REPLY', id: m.id, ok: !!(r && r.ok), error: r && r.error || '' }, location.origin); };
    try { chrome.runtime.sendMessage({ type: 'open', portal: m.portal, url: m.url, user: m.user, pw: m.pw }, r => answer(chrome.runtime.lastError ? { ok: false, error: 'The filler did not answer. Reload this page and try again.' } : r)); }
    catch (er) { answer({ ok: false, error: 'The filler was updated. Reload this page and try again.' }); }
  }
  /* addEventListener ignores a second add of the same function, so this is safe to repeat */
  function hook() { const de = document.documentElement; if (de && de.getAttribute('data-shakha-filler') !== ver) de.setAttribute('data-shakha-filler', ver); window.addEventListener('message', onMsg); }
  hook();
  new MutationObserver(hook).observe(document, { childList: true });
  setInterval(hook, 500);
})();
